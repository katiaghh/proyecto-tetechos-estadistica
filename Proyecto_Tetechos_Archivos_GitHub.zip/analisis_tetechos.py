# Analisis del proyecto: efecto ladera en ramificacion de tetechos
# Ejecutar: python analisis_tetechos.py (requiere pandas, scipy, matplotlib)

import pandas as pd
from scipy.stats import mannwhitneyu, spearmanr, chi2_contingency
import matplotlib.pyplot as plt

datos = pd.read_csv("datos_limpios_tetechos.csv")
norte = datos[datos["ladera"] == "Norte"]
sur = datos[datos["ladera"] == "Sur"]

print("Resumen por ladera")
print(datos.groupby("ladera")[["diam", "total"]].agg(["count", "mean", "median", "std"]))
print("\\nMann-Whitney: total de ramas entre laderas")
print(mannwhitneyu(norte["total"], sur["total"], alternative="two-sided"))
print("\\nMann-Whitney: diámetro basal entre laderas")
print(mannwhitneyu(norte["diam"], sur["diam"], alternative="two-sided"))
print("\\nChi-cuadrada: proporción con alguna rama registrada")
tabla = pd.crosstab(datos["ladera"], datos["total"] > 0)
print(tabla)
print(chi2_contingency(tabla))
print("\\nSpearman: diámetro y total de ramas")
print(spearmanr(datos["diam"], datos["total"]))
print("\\nConteo de ramas N y S")
print(datos[["N", "S"]].sum())

# Visualizaciones
datos.groupby("ladera")["total"].mean().plot(kind="bar", title="Promedio de ramas por ladera")
plt.ylabel("Ramificaciones N+S")
plt.tight_layout()
plt.show()

plt.scatter(norte["diam"], norte["total"], label="Norte")
plt.scatter(sur["diam"], sur["total"], label="Sur")
plt.xlabel("Diámetro basal")
plt.ylabel("Ramificaciones N+S")
plt.title("Diámetro y ramificación")
plt.legend()
plt.tight_layout()
plt.show()
