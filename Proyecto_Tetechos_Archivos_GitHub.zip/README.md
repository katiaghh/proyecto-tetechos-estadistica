# Proyecto: Efecto ladera en la ramificación de tetechos

## Archivos
- `Presentacion_Proyecto_Tetechos.pdf`: presentación con metodología, resultados, discusión y conclusiones.
- `analisis_tetechos.py`: código de análisis estadístico y gráficas.
- `datos_limpios_tetechos.csv`: tabla combinada de 122 registros.
- `grafica_*.png`: gráficas generadas para la presentación.

## Pregunta
¿La orientación norte o sur de la ladera está relacionada con la ramificación de los tetechos?

## Resultados principales (datos combinados)
- Norte: n=65; promedio 1.88 ramas N+S; 27 individuos con al menos una rama.
- Sur: n=57; promedio 1.51 ramas N+S; 17 individuos con al menos una rama.
- Mann–Whitney para total de ramas entre laderas: p=0.135 (no significativo a 0.05).
- Chi-cuadrada de presencia/ausencia de ramas: p=0.248 (no significativo).
- Correlación Spearman diámetro-total: rho=0.294, p=0.001 (asociación positiva débil).
- Conteos direccionales: 95 hacia N y 113 hacia S, en los registros que incluyen solo estas direcciones.

## Reproducir
Instalar dependencias: `pip install pandas scipy matplotlib`
En la carpeta del proyecto, ejecutar: `python analisis_tetechos.py`

## Limitaciones
El registro consolidado solo incluye ramificaciones N y S; no se analizan E/O. La muestra puede estar agrupada por equipo/cuadrante. No se midieron directamente variables ambientales ni edad de los individuos. Por ello, se trata de un análisis exploratorio, no de evidencia causal.

## Referencia bibliográfica principal
López-Gómez et al. (2012), *Efecto de la orientación de la ladera sobre la estructura poblacional y ecomorfología de Neobuxbaumia tetetzo*. Botanical Sciences, 90(4), 453–457.
